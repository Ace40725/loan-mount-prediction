# Loan-Prediction-Classification
A Classification Problem which predicts if a loan will get approved or not.

Dataset-  The data has 615 rows and 13 columns.

Dataset Description-

Variable

Description

Loan_ID - Unique Loan ID

Gender - Male/ Female

Married- Applicant married (Y/N)

Dependents - Number of dependents

Education - Applicant Education (Graduate/ Under Graduate)

Self_Employed - Self employed (Y/N)

ApplicantIncome - Applicant income

CoapplicantIncome - Coapplicant income

LoanAmount - Loan amount in thousands

Loan_Amount_Term - Term of loan in months

Credit_History - credit history meets guidelines

Property_Area - Urban/ Semi Urban/ Rural

Loan_Status - Loan approved (Y/N)
